package com.linkedin.drelephant.mapreduce.heuristics;

public class CommonConstantsHeuristic {

  public static final String MAPPER_SPEED="Mapper Speed";
  public static final String TOTAL_INPUT_SIZE_IN_MB="Total input size in MB";
}
